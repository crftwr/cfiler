#include "stdafx.h"
#include "normal.h"
